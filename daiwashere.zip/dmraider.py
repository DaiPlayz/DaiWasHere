import os
import subprocess

def install_module(module_name):
    try:
        print(f"[IMPORT] - Attempting to install: {module_name}")
        subprocess.check_call([os.sys.executable, "-m", "pip", "install", module_name])
    except Exception as e:
        print(f"[ERROR] - Could not install {module_name}: {e}")

def load_modules(file_path="modules.txt"):
    try:
        with open(file_path, "r") as file:
            return [line.strip() for line in file.readlines() if line.strip()]
    except FileNotFoundError:
        print(f"[ERROR] - {file_path} not found.")
        return []

modules = load_modules("modules.txt")
for module_name in modules:
    try:
        __import__(module_name.split(".")[0]) 
    except ModuleNotFoundError:
        install_module(module_name.split(".")[0])

try:
    import asyncio
    import discord
    from discord.ext import commands
    import threading
    from colorama import Fore, init
    import pystyle
    from pystyle import Colors, Colorate
    import pypresence
    from pypresence import Presence
    import os
    import time
    import requests
    import random
except ModuleNotFoundError as module:
    print(Fore.RED + f"[ERROR] - Could not import: {module}")

print(Fore.GREEN + "[IMPORT] - All modules imported successfully!")


init(autoreset=True)

guild_id = None #1297914924072173588
valid_tokens = []

print(Colorate.Vertical(Colors.red_to_blue, r"""
      _    _    ___  __        ___    ____    _   _ _____ ____  _____ 
   __| |  / \  |_ _| \ \      / / \  / ___|  | | | | ____|  _ \| ____|
  / _` | / _ \  | |   \ \ /\ / / _ \ \___ \  | |_| |  _| | |_) |  _|  
 | (_| |/ ___ \ | |    \ V  V / ___ \ ___) | |  _  | |___|  _ <| |___ 
  \__,_/_/   \_\___|    \_/\_/_/   \_\____/  |_| |_|_____|_| \_\_____|                           

"""))

rpc_enabled = input(Fore.GREEN + ">>> Enable Discord RPC? (Y/N): ").strip().lower() == 'y'
debug = input(Fore.GREEN + ">>> Would you like to debug? (Y/N): ").strip().lower() == 'y'
if not guild_id:
    guild_id = input(Fore.GREEN + ">>> Enter the guild id: ")
    try:
        guild_id = int(guild_id)
    except ValueError:
        print(Fore.RED + "[ERROR] - Incorrect 'int' value. Closing in 3 seconds...")
        time.sleep(3)
        exit()


if not debug:
    print(Fore.YELLOW + "[ANALYZING] - Checking tokens...")

if rpc_enabled:
    client = Presence(1306411912946388992)
    client.connect()
    client.update(details="DM Raider", state="Configuring...")


if not os.path.exists("tokens.txt"):
    print(Fore.RED + "[ERROR] - tokens.txt not found. Exiting in 3 seconds...")
    time.sleep(3)
    exit()

with open("tokens.txt", "r") as f:
    tokens = [line.strip() for line in f if line.strip()]

async def test_token(token):
    bot = commands.Bot(command_prefix="uwu", intents=discord.Intents.all())
    try:
        await bot.login(token)
        if debug:
            print(Fore.GREEN + f"[SUCCESS] - | {token} IS VALID | (USER: {bot.user.name}) (ID: {bot.user.id})")

        try:
            guild = await bot.fetch_guild(guild_id)
            if debug:
                print(Fore.GREEN + f"[SUCCESS] - | {token} IS IN SERVER | (USER: {bot.user.name}) (ID: {bot.user.id})")
            valid_tokens.append(token)
        except discord.errors.NotFound:
            print(Fore.RED + f"[ERROR] - | {token} IS NOT IN SERVER or INCORRECT GUILD! | (USER: {bot.user.name}) (ID: {bot.user.id})")
    except discord.errors.LoginFailure:
        print(Fore.RED + "[ERROR] - {token} IS NOT VALID")
    finally:
        await bot.close()

async def validate_tokens():
    await asyncio.gather(*(test_token(token) for token in tokens))

asyncio.run(validate_tokens())

if not debug:
    print(Colorate.Vertical(Colors.yellow_to_green, f"[COMPLETE] - READY TOKENS: {len(valid_tokens)}/{len(tokens)}"))
    print(Colorate.Vertical(Colors.yellow_to_green, f"[COMPLETE] - RPC ENABLED: [{'TRUE' if rpc_enabled else 'FALSE'}]"))


if valid_tokens:
    user_id = int(input(Fore.GREEN + ">>> Enter the user ID to DM: "))
    try:
        the_user = requests.post('https://discord.com/api/v9/users/@me/channels', headers={'Authorization': f'Bot {random.choice(valid_tokens)}'}, json={'recipient_id': str(user_id)}).json()['recipients'][0]['username']
    except KeyError as e:
        print(Fore.RED + f"[ERROR] - {e} ")
        time.sleep(3)
        exit()
    message_content = input(">>> Enter the message to send: ")
    loopvalue = input(">>> How many messages to send: ")
    try:
        loopvalue = int(loopvalue)
    except ValueError:
        print(Fore.RED + "[ERROR] - Incorrect 'int' value. Closing in 3 seconds...")
        time.sleep(3)
        exit()
    delayvalue = input(">>> Enter the delay of sending messages: ")
    try:
        delayvalue = int(delayvalue)
    except ValueError:
        print(Fore.RED + "[ERROR] - Incorrect 'int' value. Closing in 3 seconds...")
        time.sleep(3)
        exit()

    
    client.update(details="DM Raider", state=f"Raiding {the_user}'s dms with {len(valid_tokens)}/{len(tokens)} bots and {loopvalue}'s messages.")
    one_time_rpc_change = False
    one_time_print_error = False
    async def send_dm(bot, token):
        try:
            user = await bot.fetch_user(user_id)
        except:
            print(Fore.RED + f"[ERROR] - User is Invalid!")
            exit()


        for i in range(loopvalue):
            try:
                await user.send(message_content)
                print(Fore.GREEN + f"[SUCCESS] - Message sent by bot {bot.user}")
            except discord.errors.Forbidden:
                print(Fore.RED + f"[ERROR] - Bot {bot.user} forbidden to DM user")
            except discord.errors.HTTPException as e:
                if e.status == 429:
                    print(Fore.YELLOW + f"[RATELIMIT] Bot {bot.user} rate limited")
                else:
                    print(Fore.RED + f"[ERROR] - Bot {bot.user} encountered error: {e}")

    def run_bot(token):
        bot = commands.Bot(command_prefix="uwu", intents=discord.Intents.all())
        @bot.event
        async def on_ready():
            print(f"{Fore.GREEN}Bot logged in as {bot.user}")
            await send_dm(bot, token)

        asyncio.run(bot.start(token))

    threads = []
    for token in valid_tokens:
        thread = threading.Thread(target=run_bot, args=(token,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()
else:
    print(Fore.RED + "[ERROR] - No valid tokens available. Exiting.")
    exit()
